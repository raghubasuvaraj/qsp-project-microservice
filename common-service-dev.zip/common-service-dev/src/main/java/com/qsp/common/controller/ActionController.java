package com.qsp.common.controller;

import java.util.List;

import com.qsp.common.constants.ApiConstants;
import com.qsp.common.constants.SwaggerConstants;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.common.entity.QworldAction;
import com.qsp.common.service.ActionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Slf4j
@RestController
@RequestMapping(ApiConstants.ACTION_API)
@Api(value = SwaggerConstants.ACTION_INFO, description = SwaggerConstants.ACTION_DESC)
public class ActionController {

	@Autowired
	private ActionService service;


	@RequestMapping(value = ApiConstants.LIST, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.LIST_ACTION)
	@Cacheable("Action")
	public List<QworldAction> list() throws Exception {
		try {
			log.info("servicelist");
			return service.listAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

}



	/*
	 * @GetMapping("/get/{id}")
	 * 
	 * @ApiOperation(value = "Get Action") public ResponseEntity<QworldAction>
	 * get(@PathVariable Integer id) { try { QworldAction QworldAction =
	 * service.get(id); return new ResponseEntity<QworldAction>(QworldAction,
	 * HttpStatus.OK); } catch (NoSuchElementException e) { return new
	 * ResponseEntity<QworldAction>(HttpStatus.NOT_FOUND); } }
	 * 
	 * // RESTful API method for Create operation
	 * 
	 * @PostMapping("/save")
	 * 
	 * @ApiOperation(value = "Save Action") public ResponseEntity<String>
	 * add(@RequestBody QworldAction QworldAction) { service.save(QworldAction);
	 * return ResponseEntity.ok("Service Saved Sucessfully"); }
	 * 
	 * // RESTful API method for Update operation
	 * 
	 * @PutMapping("/update/{id}")
	 * 
	 * @ApiOperation(value = "Update Action") public ResponseEntity<?>
	 * update(@RequestBody QworldAction QworldAction, @PathVariable Integer id) {
	 * try { QworldAction existQworldAction = service.get(id);
	 * service.save(QworldAction); return new ResponseEntity<>(HttpStatus.OK); }
	 * catch (NoSuchElementException e) { return new
	 * ResponseEntity<>(HttpStatus.NOT_FOUND); } }
	 * 
	 * // RESTful API method for Delete operation
	 * 
	 * @DeleteMapping("/delete/{id}")
	 * 
	 * @ApiOperation(value = "Delete Action") public ResponseEntity<String>
	 * delete(@PathVariable Integer id) { service.delete(id); return
	 * ResponseEntity.ok("User is Deleted"); }
	 */
}
