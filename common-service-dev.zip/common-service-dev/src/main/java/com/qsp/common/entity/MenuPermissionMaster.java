package com.qsp.common.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="qw_permission_menu_mast")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class MenuPermissionMaster implements Serializable{
	
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer permissionId;
    private Integer menuId;
    private Integer subMenuId;
    private Integer roleTypeId;
    private String roleTypeName;
    private Integer permissionStatus;
    private Date createdTimestamp;
    private Date updatedTimestamp;
    
   
}
