package com.qsp.common.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qsp.common.entity.PrimaryPermissionView;
import com.qsp.common.entity.QworldAction;
import com.qsp.common.entity.QworldStatus;
import com.qsp.common.entity.SecondaryPermissionView;
import com.qsp.common.repository.ActionRespository;
import com.qsp.common.repository.MenuPrimaryRespository;
import com.qsp.common.repository.MenuSecondaryRespository;
import com.qsp.common.repository.StatusRespository;


@Service
@Transactional
@Repository
public class MenuService {
	
    @Autowired
    private MenuPrimaryRespository repoPrimary;
    
    @Autowired
    private MenuSecondaryRespository repoSecondary;

     
    public List<PrimaryPermissionView> listAllPrimary(Integer roleTypeId) {
        return repoPrimary.getMenuDetails(roleTypeId);
    }
    
    public List<SecondaryPermissionView> listAllSecondary(Integer menuId,Integer roleTypeId) {
        return repoSecondary.getMenuDetails(menuId,roleTypeId);
    }
     
     
   
}
