package com.qsp.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qsp.common.entity.PrimaryPermissionView;
import com.qsp.common.entity.QworldAction;
import com.qsp.common.entity.QworldStatus;
import com.qsp.common.entity.SecondaryPermissionView;



public interface MenuSecondaryRespository extends  JpaRepository<SecondaryPermissionView, Integer>{
	
	@Query("select a from SecondaryPermissionView a where a.menuId =:menuId and a.roleTypeId =:roleTypeId")
	List<SecondaryPermissionView> getMenuDetails(@Param("menuId")Integer menuId,@Param("roleTypeId")Integer roleTypeId);
}


