package com.qsp.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qsp.common.entity.PrimaryPermissionView;
import com.qsp.common.entity.QworldAction;
import com.qsp.common.entity.QworldStatus;




public interface MenuPrimaryRespository extends  JpaRepository<PrimaryPermissionView, Integer>{
	
	@Query("select a from PrimaryPermissionView a where a.roleTypeId =:roleTypeId")
	List<PrimaryPermissionView> getMenuDetails(@Param("roleTypeId")Integer roleTypeId);
	
}


