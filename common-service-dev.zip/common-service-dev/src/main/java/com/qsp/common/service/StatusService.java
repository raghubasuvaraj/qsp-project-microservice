package com.qsp.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qsp.common.entity.QworldAction;
import com.qsp.common.entity.QworldStatus;
import com.qsp.common.repository.ActionRespository;
import com.qsp.common.repository.StatusRespository;


@Service
@Transactional
public class StatusService {
	
    @Autowired
    private StatusRespository repo;

     
    public List<QworldStatus> listAll() {
        return repo.findAll();
    }
     
    public void save(QworldStatus ac) {
        repo.save(ac);
    }
     
}
