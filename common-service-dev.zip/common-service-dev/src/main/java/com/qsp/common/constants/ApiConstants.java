package com.qsp.common.constants;

public final class ApiConstants {

    private ApiConstants() {
        throw new AssertionError("No ApiConstants instances for you!");
    }


    public static final String ACTION_API="/api/common/action";
    public static final String LIST="/list";


    public static final String STATUS_API="/api/common/status";

    public static final String MENU_API="/api/common/menu";
    public static final String LIST_PRIMARY_MENU="/listPrimaryMenu";
    public static final String LIST_SECONDARY_MENU="/listSecondaryMenu";
}
