package com.qsp.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.common.entity.QworldAction;



public interface ActionRespository extends  JpaRepository<QworldAction, Integer>{
	
	
}


