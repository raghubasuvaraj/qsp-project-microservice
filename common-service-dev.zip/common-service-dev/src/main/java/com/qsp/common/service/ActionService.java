package com.qsp.common.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qsp.common.entity.QworldAction;
import com.qsp.common.repository.ActionRespository;


@Service
@Transactional
public class ActionService {
	
    @Autowired
    private ActionRespository repo;

     
    public List<QworldAction> listAll() {
        return repo.findAll();
    }
     
    public void save(QworldAction ac) {
        repo.save(ac);
    }
     
}
