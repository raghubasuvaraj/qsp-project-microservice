package com.qsp.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="qw_primary_perm_view")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PrimaryPermissionView implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    @Id
    private Integer menuId;
    private String menuName;
    private String menuTitle;
    private String menuDesc;
    private String menuKeywords;
    private String linkName;
    private Integer menuStatus;
    private Integer roleTypeId;
    private String roleTypeName;
    private Date createdTimestamp;
    private Date updatedTimestamp;
    @Column(name = "img_url")
    private String imageUrl;

}
