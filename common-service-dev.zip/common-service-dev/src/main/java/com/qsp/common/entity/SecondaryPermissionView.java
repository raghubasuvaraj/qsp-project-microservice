package com.qsp.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="qw_secondary_perm_view")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SecondaryPermissionView implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    @Id
    private Integer subMenuId;
    private Integer menuId;
    private String menuName;
    private String menuTitle;
    private String menuDesc;
    private String menuKeywords;
    private Integer sequence;
    private String linkName;
    private Integer menuStatus;
    private Integer roleTypeId;
    private String roleTypeName;
    private Date createdTimestamp;
    private Date updatedTimestamp;
    

}
