package com.qsp.common.constants;

public class SwaggerConstants {

    private SwaggerConstants() {
        throw new AssertionError("No SwaggerConstants instances for you!");
    }


    public static final String ACTION_INFO="Qworld Action";
    public static final String ACTION_DESC="Common Management";
    public static final String LIST_ACTION="List of Actions";

    public static final String LIST_STATUS="List of Status";
    public static final String STATUS_INFO="Qworld Status";
    public static final String STATUS_DESC="Status Management";

    public static final String MENU_INFO="Qworld Menu";
    public static final String MENU_DESC="Menu Management";
}