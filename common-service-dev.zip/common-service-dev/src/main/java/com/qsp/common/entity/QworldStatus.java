package com.qsp.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.redis.core.RedisHash;

@Entity
public class QworldStatus implements Serializable{
	
	private static final long serialVersionUID = 1L;


	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer statusId;
	    private String statusName;
	    private String statusCode;
	    private Date createdTimestamp;
	    private Date updatedTimestamp;
	    
	    
		public Integer getStatusId() {
			return statusId;
		}
		public void setStatusId(Integer statusId) {
			this.statusId = statusId;
		}
		public String getStatusName() {
			return statusName;
		}
		public void setStatusName(String statusName) {
			this.statusName = statusName;
		}
		public String getStatusCode() {
			return statusCode;
		}
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}
		public Date getCreatedTimestamp() {
			return createdTimestamp;
		}
		public void setCreatedTimestamp(Date createdTimestamp) {
			this.createdTimestamp = createdTimestamp;
		}
		public Date getUpdatedTimestamp() {
			return updatedTimestamp;
		}
		public void setUpdatedTimestamp(Date updatedTimestamp) {
			this.updatedTimestamp = updatedTimestamp;
		}
		
		
		public QworldStatus(Integer statusId, String statusName, String statusCode, Date createdTimestamp,
				Date updatedTimestamp) {
			super();
			this.statusId = statusId;
			this.statusName = statusName;
			this.statusCode = statusCode;
			this.createdTimestamp = createdTimestamp;
			this.updatedTimestamp = updatedTimestamp;
		}
		public QworldStatus() {
			super();
			// TODO Auto-generated constructor stub
		}
		

}

	
