package com.qsp.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.common.entity.QworldAction;
import com.qsp.common.entity.QworldStatus;



public interface StatusRespository extends  JpaRepository<QworldStatus, Integer>{
	
	
}


