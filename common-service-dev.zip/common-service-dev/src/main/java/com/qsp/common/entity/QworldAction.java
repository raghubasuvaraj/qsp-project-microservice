package com.qsp.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.redis.core.RedisHash;


@Entity
public class QworldAction implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer actionId;
    private String actionCategory;
    private String actionName;
    private String status;
    private Date createdTimestamp;
    private Date updatedTimestamp;
    
    
	public QworldAction() {
		super();
		// TODO Auto-generated constructor stub
	}


	public QworldAction(Integer actionId, String actionCategory, String actionName, String status,
			Date createdTimestamp, Date updatedTimestamp) {
		super();
		this.actionId = actionId;
		this.actionCategory = actionCategory;
		this.actionName = actionName;
		this.status = status;
		this.createdTimestamp = createdTimestamp;
		this.updatedTimestamp = updatedTimestamp;
	}


	public Integer getactionId() {
		return actionId;
	}


	public void setactionId(Integer actionId) {
		this.actionId = actionId;
	}


	public String getActionCategory() {
		return actionCategory;
	}


	public void setActionCategory(String actionCategory) {
		this.actionCategory = actionCategory;
	}


	public String getActionName() {
		return actionName;
	}


	public void setActionName(String actionName) {
		this.actionName = actionName;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}


	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}


	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}


	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}
    
    
    
}
