package com.qsp.common.controller;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import com.qsp.common.constants.ApiConstants;
import com.qsp.common.constants.SwaggerConstants;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.common.entity.PrimaryPermissionView;
import com.qsp.common.entity.QworldAction;
import com.qsp.common.entity.QworldStatus;
import com.qsp.common.entity.SecondaryPermissionView;
import com.qsp.common.service.ActionService;
import com.qsp.common.service.MenuService;
import com.qsp.common.service.StatusService;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;



@Slf4j
@RestController
@RequestMapping(ApiConstants.MENU_API)
@Api(value = SwaggerConstants.MENU_INFO, description = SwaggerConstants.MENU_DESC)
public class MenuController {

	@Autowired
	private MenuService service;


	@RequestMapping(value = ApiConstants.LIST_PRIMARY_MENU, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@Cacheable("PrimaryMenu")
	public List<PrimaryPermissionView> listPrimaryMenu(@RequestBody Map<String, String> requestParam) throws Exception {
		try {
			Integer roleTypeId = Integer.valueOf(requestParam.get("roleTypeId"));
			return service.listAllPrimary(roleTypeId);
		} catch (Exception e){
			throw new Exception(e.getMessage());
		}
	}
	
	@RequestMapping(value = "/getPrimaryMenu/{roleTypeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@Cacheable("PrimaryMenu")
	public List<PrimaryPermissionView> getlistPrimaryMenu(@PathVariable("roleTypeId") int roleTypeId) throws Exception {
		try {
			return service.listAllPrimary(roleTypeId);
		} catch (Exception e){
			throw new Exception(e.getMessage());
		}
	}


	@RequestMapping(value = ApiConstants.LIST_SECONDARY_MENU, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@Cacheable("SecondaryMenu")
	public List<SecondaryPermissionView> listSecondaryMenu(@RequestBody Map<String, String> requestParam) throws Exception {
		try {
			Integer roleTypeId = Integer.valueOf(requestParam.get("roleTypeId"));
			Integer menuId = Integer.valueOf(requestParam.get("menuId"));

			return service.listAllSecondary(menuId, roleTypeId);
		} catch (Exception e){
			throw new Exception(e.getMessage());
		}
	}


	@RequestMapping(value = "/getSecondaryMenu/{menuId}/{roleTypeId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@Cacheable("SecondaryMenu")
	public List<SecondaryPermissionView> getlistSecondaryMenu(@PathVariable("menuId") int menuId, @PathVariable("roleTypeId") int roleTypeId) throws Exception {
		try {
			return service.listAllSecondary(menuId, roleTypeId);
		} catch (Exception e){
			throw new Exception(e.getMessage());
		}
	}

}
