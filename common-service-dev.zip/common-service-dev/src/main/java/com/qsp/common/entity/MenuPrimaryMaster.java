package com.qsp.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="qw_primary_menu_mast")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class MenuPrimaryMaster implements Serializable{
	
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer menuId;
    private String menuName;
    private String menuTitle;
    private String menuDesc;
    private String menuKeywords;
    private String linkName;
    private Integer menuStatus;
    private Date createdTimestamp;
    private Date updatedTimestamp;
    @Column(name = "img_url")
    private String imageUrl;
    

}
