package com.qsp.common.util;



public class UserUtil {

	public static String masknull(String value) {

		if (value == null || value.equalsIgnoreCase("")) {

			value = "";
		}

		return value;
	}
}
