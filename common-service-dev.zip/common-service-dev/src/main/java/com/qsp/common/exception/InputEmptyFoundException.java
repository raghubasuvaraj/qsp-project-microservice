package com.qsp.common.exception;



public class InputEmptyFoundException extends RuntimeException{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputEmptyFoundException(String message){
        super(message);
    }
    
}