package com.qsp.user.constants;



public final class MessageConstants {
	
    private MessageConstants() {
        throw new AssertionError("No ExceptionConstants instances for you!");
    }
    
    public static final String USERNAME_NOT_EMPTY="username is not Empty";
    public static final String ROLE_TYPE_NOT_EMPTY="roletype is not Empty";
    public static final String ROLE_TYPE_ID_NOT_EMPTY="roletypeid is not Empty";
    public static final String USER_EMAIL_ID_NOT_EMPTY="useremailid is not Empty";
    
    
    public static final String USER_ID_NOT_EMPTY="userid is not empty";
    public static final String ROLE_ID_NOT_EMPTY="roleid is not empty";
    
    public static final String SEARCH_KEY_NOT_EMPTY="search key is not empty";
}
