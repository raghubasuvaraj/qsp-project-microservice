package com.qsp.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.user.entity.Visitors;
import com.qsp.user.repository.VisitorRepository;

@Service
public class VisitorService {

	@Autowired
	private VisitorRepository repository;

	public Visitors saveVisitorInfo(Visitors visitor) {
		return repository.save(visitor);
	}

}