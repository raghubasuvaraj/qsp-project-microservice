package com.qsp.user.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Users Entity Created By Raghu
 */

@Entity
@Table(name = "qw_users")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Users implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id", unique = true, nullable = false)
	@ApiModelProperty(notes = "userid")
	private Long userid;


	@Column(name = "user_name", unique = true, nullable = false, length = 50)
	@ApiModelProperty(notes = "username")
	private String username;

	
	@Column(name = "user_email_id", unique = true, nullable = false, length = 50)
	@ApiModelProperty(notes = "userEmailId")
	private String userEmailId;

	@Column(name = "password", nullable = false, length = 100)
	@ApiModelProperty(notes = "password")
	private String password;

	@Column(name = "status", nullable = false, length = 2)
	@ApiModelProperty(notes = "status")
	private Integer status;

	@Column(name = "last_login")
	@ApiModelProperty(notes = "lastLogin")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date lastLogin;

	@Column(name = "created_timestamp", nullable = false)
	@ApiModelProperty(notes = "createdTimestamp")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createdTimestamp;

	@Column(name = "updated_timestamp", nullable = false)
	@ApiModelProperty(notes = "updated_timestamp")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updatedTimestamp;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "users")
	private Set<Roles> roles = new HashSet<>();

}
