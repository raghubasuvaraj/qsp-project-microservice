package com.qsp.user.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.qsp.user.entity.RoleTypes;
import com.qsp.user.entity.Roles;
import com.qsp.user.entity.UserView;
import com.qsp.user.entity.Users;



public interface UserViewRepository extends JpaRepository<UserView, Integer>{

	 Page<UserView> findAll(Pageable pageable);


}
