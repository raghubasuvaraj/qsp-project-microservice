package com.qsp.user.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "qw_visitors")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Visitors implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "visitor_id", unique = true, nullable = false)
	@ApiModelProperty(notes = "visitorId")
	private Long visitorId;
	
	
	@Column(name = "user_name",length = 50)
	@ApiModelProperty(notes = "userName")
	private String userName;
	
	@Column(name = "ip_address",length = 50)
	@ApiModelProperty(notes = "ipAddress")
	private String ipAddress;
	
	@Column(name = "method",length = 50)
	@ApiModelProperty(notes = "method")
	private String method;
	
	@Column(name = "url",nullable = false)
	@ApiModelProperty(notes = "url")
	private String url;
	
	@Column(name = "page")
	@ApiModelProperty(notes = "page")
	private String page;
	
	@Column(name = "query_string")
	@ApiModelProperty(notes = "queryString")
	private String queryString;
	
	@Column(name = "referer_page")
	@ApiModelProperty(notes = "refererPage")
	private String refererPage;
	
	@Column(name = "user_agent")
	@ApiModelProperty(notes = "userAgent")
	private String userAgent;
	
	@Column(name = "logged_time")
	@ApiModelProperty(notes = "loggedTime")
	private Date loggedTime;
	
	@Column(name = "uniqu_visit")
	@ApiModelProperty(notes = "uniqueVisit")
	private boolean uniqueVisit;
	
	@Column(name = "user_id",length = 50)
	@ApiModelProperty(notes = "user_id")
	private Long userId;
	
	

}
