package com.qsp.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.user.entity.Visitors;

public interface VisitorRepository extends JpaRepository<Visitors, Long> {

}
