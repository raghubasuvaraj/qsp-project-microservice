package com.qsp.user.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

import com.qsp.user.apiresponse.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.user.constants.ApiConstants;
import com.qsp.user.constants.MessageConstants;
import com.qsp.user.constants.SwaggerConstants;
import com.qsp.user.constants.UserConstants;
import com.qsp.user.entity.ResponseMessage;
import com.qsp.user.entity.Roles;
import com.qsp.user.entity.UserView;
import com.qsp.user.entity.Users;
import com.qsp.user.exception.InputEmptyFoundException;
import com.qsp.user.service.RolesService;
import com.qsp.user.service.UserViewService;
import com.qsp.user.service.UserService;
import com.qsp.user.util.PasswordGen;
import com.qsp.user.util.UserUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@Slf4j
@RestController
@RequestMapping(ApiConstants.USER_API)
@Api(value = SwaggerConstants.USER_INFO, description = SwaggerConstants.USER_DESC)
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private RolesService roleservice;

	@Autowired
	private UserViewService userservice;

	@RequestMapping(value = ApiConstants.LIST, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_LIST)
	public ResponseEntity<?> list() {


		log.info("---- Entered into List of Users UserController ---- ");
		List<UserView> userView = userservice.listAll();

		if(userView.size()==0){
			ResponseModel responseModel = new ResponseModel(false, "No UserView List Available", null);
			return ResponseEntity.accepted().body(responseModel);
		}

		ResponseModel responseModel = new ResponseModel(true, "UserView Details List", userView);
		return ResponseEntity.accepted().body(responseModel);

	}

	@RequestMapping(value = ApiConstants.LIST_PAGE, params = { "page",
			"limit" }, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_LIST_PAGE)
	public ResponseEntity<?> listBySize(@RequestParam Integer page, @RequestParam Integer limit) {
		log.info("---- Entered into List of Users UserController ---- " + UserUtil.userName());

		Page<Users> list = service.findBySize(page, limit);

		if(list.getSize()==0){
			ResponseModel responseModel = new ResponseModel(false, "No Users List Available", null);
			return ResponseEntity.accepted().body(responseModel);
		}

		ResponseModel responseModel = new ResponseModel(true, "Users Details List", list);
		return ResponseEntity.accepted().body(responseModel);

	}

	@RequestMapping(value = ApiConstants.USER_LIST_PAGE, params = { "page",
			"limit" }, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_LIST_PAGE)
	public ResponseEntity<?> userListBySize(@RequestParam Integer page, @RequestParam Integer limit) {

		log.info(ApiConstants.USER_LIST_PAGE + "---- Entered into List of Users UserController ---- "
				+ UserUtil.userName());
		Page<UserView> list = userservice.findBySize(page, limit);

		if(list.getSize()==0){
			ResponseModel responseModel = new ResponseModel(false, "No UserView List Available", null);
			return ResponseEntity.accepted().body(responseModel);
		}

		ResponseModel responseModel = new ResponseModel(true, "UserView List", list);
		return ResponseEntity.accepted().body(responseModel);

	}

	@RequestMapping(value = ApiConstants.FILTER, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_FILTER)
	public List<UserView> filter(@PathVariable Integer status) {

		List<UserView> value = userservice.listAll();
		List<UserView> active;
		List<UserView> inActive;

		if (status == UserConstants.STATUS_ACTIVE) {
			active = value.stream().filter(p -> p.getStatus().equals(UserConstants.STATUS_ACTIVE_CHECK))
					.collect(Collectors.toList());
			return active;

		} else if (status == UserConstants.STATUS_INACTIVE) {

			inActive = value.stream().filter(p -> p.getStatus().equals(UserConstants.STATUS_INACTIVE_CHECK))
					.collect(Collectors.toList());
			return inActive;

		} else {
			return value;
		}

	}

	@RequestMapping(value = ApiConstants.SEARCH, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_SEARCH)
	public List<UserView> filter(@RequestBody Map<String, String> requestParam) throws ParseException {

		String searchKey = UserUtil.masknull(requestParam.get(UserConstants.SEARCH_KEY));

		if(searchKey.isEmpty()) {
			throw new InputEmptyFoundException(MessageConstants.SEARCH_KEY_NOT_EMPTY);
		}
		
		Integer status = Integer.valueOf(requestParam.get(UserConstants.STATUS));

		List<UserView> value = userservice.listAll();
		List<UserView> active;
		List<UserView> inActive;

		List<UserView> searckKeyVal = null;

		if (!searchKey.isEmpty()) {

			searckKeyVal = value.stream().filter(p -> p.getUsername().toLowerCase().contains(searchKey.toLowerCase()))
					.collect(Collectors.toList());
		}

		if (status == UserConstants.STATUS_ACTIVE) {
			active = searckKeyVal.stream().filter(p -> p.getStatus().equals(UserConstants.STATUS_ACTIVE_CHECK))
					.collect(Collectors.toList());
			return active;

		} else if (status == UserConstants.STATUS_INACTIVE) {

			inActive = searckKeyVal.stream().filter(p -> p.getStatus().equals(UserConstants.STATUS_INACTIVE_CHECK))
					.collect(Collectors.toList());
			return inActive;

		} else {

			return searckKeyVal;
		}

	}

	@RequestMapping(value = ApiConstants.GET_BY_ID, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_GET_BY_ID)
	public ResponseEntity<UserView> get(@PathVariable Integer id) {
		try {
			UserView QworldUsers = userservice.get(id);
			return new ResponseEntity<UserView>(QworldUsers, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<UserView>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value = ApiConstants.SAVE, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_SAVE)
	public ResponseEntity<?> add(@RequestBody Map<String, String> requestParam) throws Exception {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		Users users = new Users();
		try {

			Long roleTypeId = Long.valueOf(UserUtil.masknull(requestParam.get(UserConstants.ROLE_TYPE_ID)));
			
			if(roleTypeId == null) {
				throw new InputEmptyFoundException(com.qsp.user.constants.MessageConstants.ROLE_TYPE_ID_NOT_EMPTY);
			}
			
			String rolyType = UserUtil.masknull(requestParam.get(UserConstants.ROLE_TYPE));
			
			if(rolyType.isEmpty()) {
				throw new InputEmptyFoundException(MessageConstants.ROLE_TYPE_NOT_EMPTY);
			}
			
			Date sysdate = new Date();
			String userName = UserUtil.masknull(requestParam.get(UserConstants.USER_NAME));
			
			if(userName.isEmpty()) {
		         throw new InputEmptyFoundException(MessageConstants.USERNAME_NOT_EMPTY);
		    }
			
			String userEmailId = UserUtil.masknull(requestParam.get(UserConstants.USER_EMAIL_ID));
			
			if(userEmailId.isEmpty()) {
		         throw new InputEmptyFoundException(MessageConstants.USERNAME_NOT_EMPTY);
		    }		
			
			
			userName.toLowerCase();
			String password = userName;
			String encodedPassword = passwordEncoder.encode(password);
			users.setUsername(userName);
			users.setPassword(encodedPassword);
			users.setUserEmailId(userEmailId);
			users.setStatus(UserConstants.STATUS_ACTIVE);
			users.setLastLogin(sysdate);
			users.setCreatedTimestamp(sysdate);
			users.setUpdatedTimestamp(sysdate);

			Roles roles = new Roles();
			roles.setUsers(users);
			roles.setStatus(UserConstants.STATUS_ACTIVE);
			roles.setRoleType(rolyType);
			roles.setRoleTypeId(roleTypeId);
			roles.setCreatedTimestamp(sysdate);
			roles.setUpdatedTimestamp(sysdate);
			Set<Roles> rolesSet = new HashSet<>();
			rolesSet.add(roles);

			users.setRoles(rolesSet);
			service.save(users);
			users.setPassword("XXXXXXXXX");
			return new ResponseEntity<Users>(users, HttpStatus.OK);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@RequestMapping(value = ApiConstants.UPDATE, method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_UPDATE)
	public ResponseEntity<?> update(@RequestBody Map<String, String> requestParam) throws Exception {
		try {

			Date sysdate = new Date();
			Long userId = Long.valueOf(UserUtil.masknull(requestParam.get(UserConstants.USER_ID)));
			
			if(userId == null) {
				throw new InputEmptyFoundException(MessageConstants.USER_ID_NOT_EMPTY);
			}
			
			Long roleId = Long.valueOf(UserUtil.masknull(requestParam.get(UserConstants.ROLE_ID)));
			
			if(roleId == null) {
				throw new InputEmptyFoundException(MessageConstants.ROLE_ID_NOT_EMPTY);
			}
			Integer status = Integer.valueOf(requestParam.get(UserConstants.STATUS));
			Long roleTypeId = Long.valueOf(UserUtil.masknull(requestParam.get(UserConstants.ROLE_TYPE_ID)));
			
			if(roleTypeId == null) {
				throw new InputEmptyFoundException(MessageConstants.ROLE_TYPE_ID_NOT_EMPTY);
			}

			String rolyType = UserUtil.masknull(requestParam.get(UserConstants.ROLE_TYPE));
			
			if(rolyType.isEmpty()) {
				throw new InputEmptyFoundException(MessageConstants.ROLE_TYPE_NOT_EMPTY);
			}

			Users users = service.get(userId);
			String userName = requestParam.get(UserConstants.USER_NAME);
			userName.toLowerCase();
			users.setUsername(userName);
			users.setUserEmailId(requestParam.get(UserConstants.USER_EMAIL_ID));
			users.setStatus(status);
			users.setPassword(users.getPassword());
			users.setCreatedTimestamp(users.getCreatedTimestamp());
			users.setUpdatedTimestamp(sysdate);

			Roles roles = roleservice.get(userId);
			roles.setRoleId(roleId);
			roles.setUsers(users);
			roles.setRoleType(rolyType);
			roles.setRoleTypeId(roleTypeId);
			roles.setStatus(status);
			roles.setCreatedTimestamp(users.getCreatedTimestamp());
			roles.setUpdatedTimestamp(sysdate);
			Set<Roles> rolesSet = new HashSet<>();
			rolesSet.add(roles);
			users.setRoles(rolesSet);
			service.save(users);
			users.setPassword("XXXXXXXXX");
			return new ResponseEntity<Users>(users, HttpStatus.OK);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	@RequestMapping(value = ApiConstants.RESET_PASSWORD, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_RESET_PASSWORD)
	public ResponseEntity<?> resetpassword(@PathVariable Long id) throws MessagingException {
		try {

			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

			// SMTP server information
			Users users = service.get(id);

			String newpassword = passwordEncoder.encode(PasswordGen.generatePassword(5).toString());

			// outgoing message information
			String toAddress = users.getUserEmailId();

			// message contains HTML markups
			String message = "<i>Password Reset : </i><br>";
			message += "<b>" + newpassword + "</b><br>";

			// sets SMTP server properties
			Properties properties = new Properties();
			properties.put("mail.smtp.host", UserConstants.HOST);
			properties.put("mail.smtp.port", UserConstants.PORT);
			properties.put("mail.smtp.auth", "true");
			properties.put("mail.smtp.starttls.enable", "true");

			// creates a new session with an authenticator
			Authenticator auth = new Authenticator() {
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(UserConstants.MAIL_NAME, UserConstants.PASSWORD);
				}
			};

			Session session = Session.getInstance(properties, auth);

			// creates a new e-mail message
			Message msg = new MimeMessage(session);

			try {
				msg.setFrom(new InternetAddress(UserConstants.MAIL_NAME));
				InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
				msg.setRecipients(Message.RecipientType.TO, toAddresses);
				msg.setSubject(UserConstants.SUBJECT);
				msg.setSentDate(new Date());
				// set plain text message
				msg.setContent(message, "text/html");

				// sends the e-mail
				Transport.send(msg);
				Date sysdate = new Date();
				users.setPassword(newpassword);
				users.setUpdatedTimestamp(sysdate);
				service.save(users);

			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				throw new MessagingException(e.getMessage());
			}

			ResponseMessage responsemessage = new ResponseMessage();
			responsemessage.setMesssage(UserConstants.PASSWORD_RESET_SUCESS);
			return new ResponseEntity<ResponseMessage>(responsemessage, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value = ApiConstants.DELETE_BY_ID, method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.USER_DELETE_BY_ID)
	public ResponseEntity<String> delete(@PathVariable Long id) {
		service.delete(id);
		return ResponseEntity.ok("User is Deleted");
	}

}
