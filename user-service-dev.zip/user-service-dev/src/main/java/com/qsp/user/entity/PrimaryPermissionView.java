package com.qsp.user.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PrimaryPermissionView implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
    @Id
    private Integer menuId;
    private String menuName;
    private String menuTitle;
    private String menuDesc;
    private String menuKeywords;
    private String linkName;
    private Integer menuStatus;
    private Integer roleTypeId;
    private String roleTypeName;
    private Date createdTimestamp;
    private Date updatedTimestamp;
    

}
