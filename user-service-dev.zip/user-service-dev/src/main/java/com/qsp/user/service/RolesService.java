package com.qsp.user.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.user.entity.RoleTypes;
import com.qsp.user.entity.Roles;
import com.qsp.user.entity.Users;
import com.qsp.user.repository.RoleTypeRepository;
import com.qsp.user.repository.RolesRepository;
import com.qsp.user.repository.UserRepository;


@Service
public class RolesService{

	 
	    @Autowired
	    private RolesRepository repo;
	  
	    
	    public List<Roles> listAll() {
	        return repo.findAll();
	    }
	     
	    public void save(Roles users) {
	        repo.save(users);
	    }
	     
	    public Roles get(Long id) {
	        return repo.findById(id).get();
	    }

	    public void delete(Long id) {
	        repo.deleteById(id);
	    }


}
