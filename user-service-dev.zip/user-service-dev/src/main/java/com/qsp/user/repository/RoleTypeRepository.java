package com.qsp.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qsp.user.entity.RoleTypes;
import com.qsp.user.entity.Users;



public interface RoleTypeRepository extends JpaRepository<RoleTypes, Long>{


	 @Query("select a from RoleTypes a where a.roleTypeId in (1,2,4)")
	 public  List<RoleTypes> getRoleTypes();
	 
	 @Query("select a from RoleTypes a where a.roleTypeId in (3,5,6)")
	 public List<RoleTypes> getRoleTypespd();
	 
}
