package com.qsp.user.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="qw_user_view")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserView implements Serializable {


    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "user_id", unique = true, nullable = false)
    private Integer userid;
    
    @Column(name = "role_id", unique = true, nullable = false)
    private Integer roleId;
    
    @Column(name = "user_name", unique = true, nullable = false, length = 50)
    private String username;
    
    @Column(name = "user_email_id", unique = true, nullable = false, length = 50)
	@ApiModelProperty(notes = "userEmailId")
    private String userEmailId;
    
    @Column(name = "role_type_id",nullable = false)
	private Long roleTypeId;

	@Column(name = "role_type", nullable = false, length = 50)
	@ApiModelProperty(notes = "roleType")
	private String roleType;

	@Column(name = "status", nullable = false)
	@ApiModelProperty(notes = "status")
	private String status;
    
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @Column(name="created_timestamp")
    private Date createdTimestamp;
    
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @Column(name="last_login_date")
    private Date lastLoginDate;
    

}
