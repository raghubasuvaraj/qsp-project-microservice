package com.qsp.user.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qsp.user.entity.RoleTypes;
import com.qsp.user.entity.Users;
import com.qsp.user.repository.RoleTypeRepository;
import com.qsp.user.repository.UserRepository;


@Service
public class RoleTypeService{

	 
	    @Autowired
	    private RoleTypeRepository repo;
	  
	    
	    public List<RoleTypes> listAll() {
	        return repo.findAll();
	    }

	    public List<RoleTypes> getRoleTypes() {
	        return repo.getRoleTypes();
	    }
	    
	    public List<RoleTypes> getRoleTypespd() {
	        return repo.getRoleTypespd();
	    }
	     
	    public void save(RoleTypes users) {
	        repo.save(users);
	    }
	     
	    public RoleTypes get(Long id) {
	        return repo.findById(id).get();
	    }

	    public void delete(Long id) {
	        repo.deleteById(id);
	    }


}
