package com.qsp.user.constants;

public final class ApiConstants {
	
    private ApiConstants() {
        throw new AssertionError("No ApiConstants instances for you!");
    }
	public static final String USER_API="/api/user";
	public static final String LIST="/list";
	public static final String LIST_PAGE="/listPage";
	public static final String USER_LIST_PAGE="/userListPage";
	public static final String SAVE="/save";
	public static final String UPDATE="/update";
	public static final String DELETE="/delete";
	public static final String FILTER="/filter/{status}";
	public static final String SEARCH="/search";
	public static final String GET_BY_ID="/get/{id}";
	public static final String RESET_PASSWORD ="/resetpassword/{id}";
	public static final String DELETE_BY_ID= "/delete/{id}";
	public static final String USER_ROLE_API="/api/user/role";

	public static final String LIST_PA_ROLES="/listOfPARoles";
	public static final String LIST_PD_ROLES="/listOfPDRoles";

	public static final String VALIDATE_TOKEN="/validateToken";
	public static final String AUTHENTICATE="/authenticate";
}
