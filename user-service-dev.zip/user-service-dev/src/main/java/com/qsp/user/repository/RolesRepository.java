package com.qsp.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.user.entity.RoleTypes;
import com.qsp.user.entity.Roles;
import com.qsp.user.entity.Users;



public interface RolesRepository extends JpaRepository<Roles, Long>{



}
