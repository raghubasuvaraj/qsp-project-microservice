package com.qsp.user.constants;

public final class UserConstants {
	
    private UserConstants() {
        throw new AssertionError("No UserConstants instances for you!");
    }
	
	
	public static final Integer STATUS_ACTIVE = 1;
	public static final Integer STATUS_INACTIVE =0;
	
	
	public static final String STATUS_ACTIVE_CHECK = "1";
	public static final String STATUS_INACTIVE_CHECK ="0";
	
	public static final String PASSWORD="password";
	public static final String ROLE_TYPE_ID="roleTypeId";
	public static final String ROLE_TYPE="roleType";
	public static final String USER_NAME="username";
	public static final String USER_EMAIL_ID="userEmailId";
	public static final String USER_ID="userid";
	public static final String STATUS="status";
	public static final String ROLE_ID="roleId";
	public static final String SEARCH_KEY="searchKey";
	public static final String PASSWORD_RESET_SUCESS="Password Reset Successfully.Kindly check Your mail.";
	
	public static final String HOST = "smtp.gmail.com";
	public static final String PORT = "587";
	public static final String MAIL_NAME = "raghu@heptagon.in";
	public static final String MAIL_PASSWORD = "Qworld4443!$#";
	public static final String SUBJECT = "Password Reset";
}
