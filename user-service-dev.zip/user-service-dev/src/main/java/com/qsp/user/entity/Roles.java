package com.qsp.user.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "qw_roles")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Roles implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "role_id", unique = true, nullable = false)
	@ApiModelProperty(notes = "roleId")
	private Long roleId;

	@Column(name = "role_type_id",nullable = false)
	private Long roleTypeId;

	@Column(name = "role_type", nullable = false, length = 50)
	@ApiModelProperty(notes = "roleType")
	private String roleType;

	@Column(name = "status", nullable = false)
	@ApiModelProperty(notes = "status")
	private Integer status;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "created_timestamp", nullable = false)
	@ApiModelProperty(notes = "createdTimestamp")
	private Date createdTimestamp;

	@Column(name = "updated_timestamp", nullable = false)
	@ApiModelProperty(notes = "updated_timestamp")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updatedTimestamp;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	@JsonIgnore
	private Users users;

}
