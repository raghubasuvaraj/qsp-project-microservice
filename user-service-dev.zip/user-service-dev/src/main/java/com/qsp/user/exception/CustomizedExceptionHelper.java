package com.qsp.user.exception;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CustomizedExceptionHelper {
	
	 private static final Logger logger = LoggerFactory.getLogger(CustomizedExceptionHelper.class);

	  @ExceptionHandler(value = { InvalidInputException.class })
	  public ResponseEntity<Object> handleInvalidInputException(InvalidInputException ex) {
		  logger.error("Invalid Input Exception: ",ex.getMessage());
		  String defaultMessage = "Invalid Input Exception: "+ex.getMessage();
		  ErrorDetails apiError = new ErrorDetails(new Date(),defaultMessage,"ER-CD-004",HttpStatus.NOT_FOUND.value(),ex.getLocalizedMessage());
		  return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());

	  }
	  
	  
	  @ExceptionHandler(value = { InputEmptyFoundException.class })
	  public ResponseEntity<Object> handleInputException(InputEmptyFoundException ex) {
		  logger.error("Invalid Input Exception: ",ex.getMessage());
		  String defaultMessage = "Input Empty Exception: "+ex.getMessage();
		  ErrorDetails apiError = new ErrorDetails(new Date(),defaultMessage,"ER-CD-005",HttpStatus.NOT_FOUND.value(),ex.getLocalizedMessage());
		  return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());

	  }
	  
    @ExceptionHandler(value = {MethodArgumentNotValidException.class })
    public ResponseEntity<Object> handleValidationError(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        FieldError fieldError = bindingResult.getFieldError();
        String defaultMessage = fieldError.getDefaultMessage();
        ErrorDetails apiError = new ErrorDetails(new Date(),defaultMessage,"ER-CD-006",HttpStatus.NOT_FOUND.value(),ex.getLocalizedMessage());
        return new ResponseEntity<Object>(apiError, new HttpHeaders(), apiError.getStatus());
    }
    

}
