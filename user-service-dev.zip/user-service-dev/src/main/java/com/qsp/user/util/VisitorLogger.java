package com.qsp.user.util;

import java.time.LocalDateTime;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.qsp.user.entity.Users;
import com.qsp.user.entity.Visitors;
import com.qsp.user.service.UserService;
import com.qsp.user.service.VisitorService;

@Component
public class VisitorLogger implements HandlerInterceptor {

	@Autowired
	private VisitorService visitorService;
	
	@Autowired
	private UserService service;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		final String ip = HttpRequestResponseUtils.getClientIpAddress(request);
		final String url = HttpRequestResponseUtils.getRequestUrl(request);
		final String page = HttpRequestResponseUtils.getRequestUri(request);
		final String refererPage = HttpRequestResponseUtils.getRefererPage(request);
		final String queryString = HttpRequestResponseUtils.getPageQueryString(request);
		final String userAgent = HttpRequestResponseUtils.getUserAgent(request);
		final String requestMethod = HttpRequestResponseUtils.getRequestMethod(request);
		final Date timestamp = new Date();

		Visitors visitor = new Visitors();
		visitor.setIpAddress(ip);
		visitor.setMethod(requestMethod);
		visitor.setUrl(url);
		visitor.setPage(page);
		visitor.setQueryString(queryString);
		visitor.setRefererPage(refererPage);
		visitor.setUserAgent(userAgent);
		visitor.setLoggedTime(timestamp);
		visitor.setUniqueVisit(true);
		
		String username = UserUtil.masknull(HttpRequestResponseUtils.getLoggedInUser());
		
		if(!username.isEmpty()) {
		visitor.setUserName(username);	
	    Users users = service.getByUserName(username);
	    visitor.setUserId(users.getUserid());
		}else {
			visitor.setUserName("System");	
		}

		if(page.contains("validateToken") || page.contains("authenticate")) {
			return true;
		}else {
			
			visitorService.saveVisitorInfo(visitor);
		}
		return true;
	}

}