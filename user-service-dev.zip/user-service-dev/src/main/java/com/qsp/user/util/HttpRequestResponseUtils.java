package com.qsp.user.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.context.request.RequestContextHolder;

import com.qsp.user.entity.Users;
import com.qsp.user.service.UserService;


public final class HttpRequestResponseUtils {



	
	private HttpRequestResponseUtils(HttpServletRequest request) {
	}
	

	private static final String[] IP_HEADER_CANDIDATES = { "X-Forwarded-For", "Proxy-Client-IP", "WL-Proxy-Client-IP",
			"HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_CLIENT_IP",
			"HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "HTTP_VIA", "REMOTE_ADDR" };

	public static String getClientIpAddress(HttpServletRequest request) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "0.0.0.0";
		}


		for (String header : IP_HEADER_CANDIDATES) {
			String ipList = request.getHeader(header);
			if (ipList != null && ipList.length() != 0 && !"unknown".equalsIgnoreCase(ipList)) {
				String ip = ipList.split(",")[0];
				return ip;
			}
		}

		return request.getRemoteAddr();
	}

	public static String getRequestUrl(HttpServletRequest request) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "";
		}
		return request.getRequestURL().toString();
	}

	public static String getRequestUri(HttpServletRequest request) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "";
		}

		return request.getRequestURI();
	}

	public static String getRefererPage(HttpServletRequest request) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "";
		}

		String referer = request.getHeader("Referer");

		return referer != null ? referer : request.getHeader("referer");
	}

	public static String getPageQueryString(HttpServletRequest request ) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "";
		}

		return request.getQueryString();
	}

	public static String getUserAgent(HttpServletRequest request) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "";
		}

		String userAgent = request.getHeader("User-Agent");

		return userAgent != null ? userAgent : request.getHeader("user-agent");
	}

	public static String getRequestMethod(HttpServletRequest request ) {

		if (RequestContextHolder.getRequestAttributes() == null) {
			return "";
		}

		return request.getMethod();
	}

	public static String getLoggedInUser() {
		String userName = null;
		if (SecurityContextHolder.getContext().getAuthentication() != null
				&& SecurityContextHolder.getContext().getAuthentication().isAuthenticated()
				&& !(SecurityContextHolder.getContext().getAuthentication() instanceof AnonymousAuthenticationToken)) {

			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            userName = user.getUsername();
		}

		return userName;
	}

}