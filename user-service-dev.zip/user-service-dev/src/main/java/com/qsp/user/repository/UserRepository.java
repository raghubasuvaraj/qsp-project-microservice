package com.qsp.user.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qsp.user.entity.Users;



public interface UserRepository extends JpaRepository<Users, Long>{

	Users findByUsername(String username);

	Page<Users> findAll(Pageable pageable);

	 @Query("select a from Users a where a.username=:username")
	 Users findUserDetails(@Param("username")String username);
}
