package com.qsp.user.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import com.qsp.user.constants.ApiConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import com.qsp.user.entity.AuthRequest;
import com.qsp.user.entity.PrimaryPermissionView;
import com.qsp.user.entity.ResponseMessage;
import com.qsp.user.entity.Roles;
import com.qsp.user.entity.TokenJwt;
import com.qsp.user.entity.Users;
import com.qsp.user.exception.AccessDeniedException;
import com.qsp.user.service.UserService;
import com.qsp.user.util.JwtUtil;

import io.jsonwebtoken.MalformedJwtException;

@RestController
@RequestMapping("/api/user")
public class AuthController {

	@Autowired
	private JwtUtil jwtUtil;
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private UserService service;

	@Autowired
	RestTemplate restTemplate;

	@PostMapping(ApiConstants.AUTHENTICATE)
	public ResponseEntity<?> generateToken(@RequestBody AuthRequest authRequest, HttpServletRequest request)
			throws Exception {
		ResponseMessage msg = new ResponseMessage();
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
		} catch (DisabledException e) {
			throw new DisabledException(e.getMessage());
		} catch (BadCredentialsException e) {
			throw new BadCredentialsException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		TokenJwt qwtoken = new TokenJwt();
		String username = authRequest.getUsername();
		String token = jwtUtil.generateToken(authRequest.getUsername());
		Users userDetails = service.getByUserName(username);
		Set<Roles> roles = userDetails.getRoles();
		List<PrimaryPermissionView> getMenus = new ArrayList();
		for (Roles getRole : roles) {
			Long roleTypeId = getRole.getRoleId();
			int roleTypeIdGet = roleTypeId.intValue();
			getMenus = getMenus(request, roleTypeIdGet);
		}
		qwtoken.setToken(token);
		qwtoken.setUsername(userDetails.getUsername());
		qwtoken.setUserid(userDetails.getUserid());
		qwtoken.setToken(token);
		qwtoken.setRoles(roles);
		qwtoken.setMenus(getMenus);
		return new ResponseEntity<TokenJwt>(qwtoken, HttpStatus.OK);
	}

	private List<PrimaryPermissionView> getMenus(HttpServletRequest request, int roleTypeId) {

		String url ="http://COMMON-SERVICE/api/common/menu/getPrimaryMenu/"
				 +roleTypeId;
		//String token = CommonUtil.getJwtTokenFromRequest(request).toString();
		//String token="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTY0NDYzMzA5MiwiaWF0IjoxNjQzMjcwOTI3fQ.RfUGeGooTwJxPaJXOqQzMGmrcXZv3g6LiRdpz3Nb3yY";
		ResponseEntity<PrimaryPermissionView[]> responseEntity = restTemplate.getForEntity(url,PrimaryPermissionView[].class);
		List<PrimaryPermissionView> menus = Arrays.asList(responseEntity.getBody());

		return menus;
	}

	public static HttpHeaders getHeaders(String token) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		if (token != null) {
			headers.set("Authorization", token);
		}
		return headers;
	}

	@GetMapping(ApiConstants.VALIDATE_TOKEN)
	public ResponseEntity<?> tokenValidation(@RequestParam String token) throws Exception {
		String userName = null;
		try {

			if (!jwtUtil.isTokenExpired(token)) {
				userName = jwtUtil.extractUsername(token);
			}

		} catch (AccessDeniedException e) {
			throw new AccessDeniedException(e.getMessage());
		} catch (MalformedJwtException e) {
			throw new MalformedJwtException(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

		Users userDetails = service.getByUserName(userName);
		return new ResponseEntity<Users>(userDetails, HttpStatus.OK);

	}

}
