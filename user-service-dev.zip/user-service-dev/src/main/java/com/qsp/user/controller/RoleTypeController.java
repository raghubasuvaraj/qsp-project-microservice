package com.qsp.user.controller;

import java.util.List;

import com.qsp.user.apiresponse.ResponseModel;
import com.qsp.user.constants.ApiConstants;
import com.qsp.user.constants.SwaggerConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.user.entity.RoleTypes;
import com.qsp.user.service.RoleTypeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Slf4j
@RestController
@RequestMapping(ApiConstants.USER_ROLE_API)
@Api(value = SwaggerConstants.USER_ROLE_INFO, description = SwaggerConstants.USER_ROLE_DESC)
public class RoleTypeController {
	
	@Autowired
	private RoleTypeService service;
	
	
	@RequestMapping(value = ApiConstants.LIST, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.ROLES_LIST)
	public ResponseEntity<?> list() {

		log.info("servicelist");
		List<RoleTypes> roleTypes = service.listAll();

		if(roleTypes.size()==0){
			ResponseModel responseModel = new ResponseModel(false, "No roleTypes List Available", null);
			return ResponseEntity.accepted().body(responseModel);
		}

		ResponseModel responseModel = new ResponseModel(true, "roleTypes Details List", roleTypes);
		return ResponseEntity.accepted().body(responseModel);

	}
	
	@RequestMapping(value = ApiConstants.LIST_PA_ROLES, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.ROLES_LIST)
	public ResponseEntity<?> listOfPARoles() {


		log.info("servicelist");
		List<RoleTypes> roleTypes = service.getRoleTypes();

		if(roleTypes.size()==0){
			ResponseModel responseModel = new ResponseModel(false, "No roleTypes List Available", null);
			return ResponseEntity.accepted().body(responseModel);
		}

		ResponseModel responseModel = new ResponseModel(true, "roleTypes Details List", roleTypes);
		return ResponseEntity.accepted().body(responseModel);

	}
	
	
	@RequestMapping(value = ApiConstants.LIST_PD_ROLES, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = SwaggerConstants.ROLES_LIST)
	public ResponseEntity<?> listOfPDRoles() {

		log.info("servicelist");
		List<RoleTypes> roleTypes = service.getRoleTypespd();

		if(roleTypes.size()==0){
			ResponseModel responseModel = new ResponseModel(false, "No roleTypes List Available", null);
			return ResponseEntity.accepted().body(responseModel);
		}

		ResponseModel responseModel = new ResponseModel(true, "roleTypes Details List", roleTypes);
		return ResponseEntity.accepted().body(responseModel);

	}
	
	
}
