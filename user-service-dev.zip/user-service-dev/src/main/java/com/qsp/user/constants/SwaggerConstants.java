package com.qsp.user.constants;

public final class SwaggerConstants {
	
    private SwaggerConstants() {
        throw new AssertionError("No SwaggerConstants instances for you!");
    }
	
	public static final String USER_INFO="User API Info";
	public static final String USER_DESC="User Management";
	public static final String USER_LIST="List of Users";
	public static final String USER_LIST_PAGE="List of Users Pagination";
	public static final String USER_SAVE="User Save";
	public static final String USER_UPDATE="User Update";
	public static final String USER_DELETE="User Delete";
	public static final String USER_FILTER="Users Filter By Status";
	public static final String USER_SEARCH="Users Search By Keyword";
	public static final String USER_GET_BY_ID="Get User By Id";
	public static final String USER_RESET_PASSWORD ="Reset the Password for User";
	public static final String USER_DELETE_BY_ID= "Delete User BY Id";
	public static final String USER_ROLE_INFO="Qworld Role Type Controller";
	public static final String USER_ROLE_DESC="User Management";

	public static final String ROLES_LIST="List of Roles";
}
