package com.qsp.user.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class TokenJwt implements Serializable {

	private static final long serialVersionUID = 1L;

	private String token;
	private String username;
	private Long userid;
	private Set<Roles> roles = new HashSet<>();
	private List<PrimaryPermissionView> menus = new ArrayList();

}
