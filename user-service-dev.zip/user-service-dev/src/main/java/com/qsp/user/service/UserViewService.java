package com.qsp.user.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.qsp.user.entity.RoleTypes;
import com.qsp.user.entity.Roles;
import com.qsp.user.entity.UserView;
import com.qsp.user.entity.Users;
import com.qsp.user.repository.RoleTypeRepository;
import com.qsp.user.repository.RolesRepository;
import com.qsp.user.repository.UserViewRepository;
import com.qsp.user.repository.UserRepository;


@Service
public class UserViewService{

	 
	    @Autowired
	    private UserViewRepository repo;
	  
	    
	    public List<UserView> listAll() {
	        return repo.findAll();
	    }
	     
	    public void save(UserView users) {
	        repo.save(users);
	    }
	     
	    public UserView get(int id) {
	        return repo.findById(id).get();
	    }

	    public void delete(int id) {
	        repo.deleteById(id);
	    }
	    
	    public Page<UserView> findBySize(int page, int size) {

				Pageable pageable = PageRequest.of(page, size);
				Page<UserView> data = repo.findAll(pageable);
				
				return data;
		    }
		    

}
