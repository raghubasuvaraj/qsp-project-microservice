package com.qsp.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.qsp.user.entity.Roles;
import com.qsp.user.entity.Users;
import com.qsp.user.repository.UserRepository;


@Service
public class UserService implements UserDetailsService{

	 
	    @Autowired
	    private UserRepository repo;
	    
	    @Override
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	    	Users user = repo.findByUsername(username);
	    	 List<SimpleGrantedAuthority> authorities = new ArrayList<>();
	    	 Set<Roles> roles = user.getRoles();
	         for (Roles role : roles) {
	             authorities.add(new SimpleGrantedAuthority(role.getRoleType()));
	         }
	    	
	        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), authorities);
	    }
	     
	    
	    public List<Users> listAll() {
	        return repo.findAll();
	    }
	     
	    public void save(Users users) {
	        repo.save(users);
	    }
	     
	    public Users get(Long id) {
	        return repo.findById(id).get();
	    }
	    
	    public Users getByUserName(String username) {
	        return repo.findUserDetails(username);
	    }

	    public void delete(Long id) {
	        repo.deleteById(id);
	    }
	    
	    
	    public Page<Users> findBySize(int page, int size) {

			Pageable pageable = PageRequest.of(page, size);
			Page<Users> data = repo.findAll(pageable);
			
			return data;
	    }
	    
	    
}
