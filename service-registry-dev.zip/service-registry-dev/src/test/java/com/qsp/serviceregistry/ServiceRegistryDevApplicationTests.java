package com.qsp.serviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryDevApplicationTests {

	@Test
	void contextLoads() {
	}

}
